/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package quickchat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
     }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String username = "kyle_1";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.checkUserName(username);
        assertEquals(expResult, result);
        
        username = "kyle!!!!!!";
        expResult = false;
        result = instance.checkUserName(username);
        assertEquals(expResult, result);
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "Ch&&sec@ke99!";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        
        password = "password";
        expResult = false;
        result = instance.checkPasswordComplexity(password);
        assertEquals(expResult, result);
    }

    /**
     * Test of checkCellPhoneNumber method, of class Login.
     */
    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String cell = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkCellPhoneNumber(cell);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "kyle_1";
        String password = "Ch&&sec@ke99!";
        String cell = "+27838968976";
        Login instance = new Login();
        String expResult = "Registration successful";
        String result = instance.registerUser(username, password, cell);
        assertEquals(expResult, result);
        
        username = "kyle!!!!!!";
        password = "password";
        cell = "08966553";
        expResult = "Registration failed. Please ensure the username and password meet the requirement.";
        result = instance.registerUser(username, password, cell);
        assertEquals(expResult, result);
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "kyle_1";
        String password = "Ch&&sec@ke99!";
        Login instance = new Login();
        String expResult = "Login succesful";
        String result = instance.loginUser(username, password);
        assertEquals(expResult, result);
        
        username = "kyle!!!!!!";
        password = "password";
        expResult = "Login failed. Incorrect username or password.";
        result = instance.loginUser(username, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean isLoggedIn = true;
        String firstName = "Kyle";
        String lastName = "Horrman";
        Login instance = new Login();
        String expResult = "Welcome user to the registration and login system";
        String result = instance.returnLoginStatus(isLoggedIn, firstName, lastName);
        assertEquals(expResult, result);
        
        isLoggedIn = false;
        firstName = "Lyle";
        lastName = "Sumner";
        expResult = "User does not exist.";
        result = instance.returnLoginStatus(isLoggedIn, firstName, lastName);
        assertEquals(expResult, result);
    }
    
}
