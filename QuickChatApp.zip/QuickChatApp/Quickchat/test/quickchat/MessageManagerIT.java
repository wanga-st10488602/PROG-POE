/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package quickchat;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_Lab
 */
public class MessageManagerIT {
    
    public MessageManagerIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of displaySenderRecipientForAllSent method, of class MessageManager.
     */
    @Test
    public void testDisplaySenderRecipientForAllSent() {
        System.out.println("displaySenderRecipientForAllSent");
        MessageManager instance = new MessageManager();
        instance.displaySenderRecipientForAllSent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findAndDisplayLongestMessage method, of class MessageManager.
     */
    @Test
    public void testFindAndDisplayLongestMessage() {
        System.out.println("findAndDisplayLongestMessage");
        MessageManager instance = new MessageManager();
        String expResult = "";
        String result = instance.findAndDisplayLongestMessage();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByMessageID method, of class MessageManager.
     */
    @Test
    public void testSearchByMessageID() {
        System.out.println("searchByMessageID");
        String id = "";
        MessageManager instance = new MessageManager();
        String expResult = "";
        String result = instance.searchByMessageID(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchMessageByRecipient method, of class MessageManager.
     */
    @Test
    public void testSearchMessageByRecipient() {
        System.out.println("searchMessageByRecipient");
        String number = "";
        MessageManager instance = new MessageManager();
        ArrayList<String> expResult = null;
        ArrayList<String> result = instance.searchMessageByRecipient(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteMessageByHash method, of class MessageManager.
     */
    @Test
    public void testDeleteMessageByHash() {
        System.out.println("deleteMessageByHash");
        String hash = "";
        MessageManager instance = new MessageManager();
        boolean expResult = false;
        boolean result = instance.deleteMessageByHash(hash);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayFullReport method, of class MessageManager.
     */
    @Test
    public void testDisplayFullReport() {
        System.out.println("displayFullReport");
        MessageManager instance = new MessageManager();
        instance.displayFullReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
