/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package quickchat;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_Lab
 */
public class MessageTest {
    
    public MessageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkMessageId method, of class Message.
     */
    @Test
    public void testCheckMessageId() {
        System.out.println("checkMessageId");
        Message instance = new Message();
        String messageId = "ABCDEF";
        boolean expResult = false;
        boolean result = instance.checkMessageId(messageId);
        assertEquals(expResult, result);
        
        messageId = "abcdefghij";
        expResult = true;
        result = instance.checkMessageId(messageId);
        assertEquals(expResult, result);
    }

    /**
     * Test of checkRecipientCell method, of class Message.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        Message instance = new Message();
        boolean expResult = false;
        boolean result = instance.checkRecipientCell();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of checkMessageLength method, of class Message.
     */
    @Test
    public void testCheckMessageLength() {
        System.out.println("checkMessageLength");
        Message instance = new Message();
        boolean expResult = false;
        boolean result = instance.checkMessageLength();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of createMessageHash method, of class Message.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        Message instance = new Message();
        String expResult = "";
        String result = instance.createMessageHash();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of isValid method, of class Message.
     */
    @Test
    public void testIsValid() {
        System.out.println("isValid");
        Message instance = new Message();
        boolean expResult = false;
        boolean result = instance.isValid();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of printMessage method, of class Message.
     */
    @Test
    public void testPrintMessage() {
        System.out.println("printMessage");
        Message instance = new Message();
        String expResult = "";
        String result = instance.printMessage();
        assertEquals(expResult, result);
       
    }
    
}
