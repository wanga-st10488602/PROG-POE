/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quickchat;

/**
 *
 * @author RC_Student_Lab
 */
//Class for registration and login logic
public class Login {
    //Variables for storing user details
    private String registeredUsername;
    private String registeredPassword;
    private String registredCell; 
    private String firstName;
    private String lastName; 
    
    //Checks username rules
    public boolean checkUserName(String username) {
        boolean hasUnderscore = username.contains("_");
        boolean correctLength = username.length() <=5;
        return hasUnderscore && correctLength;
    }
    //Checks password rules
    public boolean checkPasswordComplexity(String password) {
        boolean hasUppercase = password.matches(".*[A-Z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[!@#$%^&*()-+=].*");
        boolean correctLength = password.length() >=8;
        return hasUppercase && hasDigit && hasSpecialChar && correctLength;
    }
    
    //Checks cell phone number rules
    public boolean checkCellPhoneNumber(String cell) {
        if (cell.matches("^\\+\\d{7,15}$")) {
            return true;
        } else{
        return false;
        }
    }
    // Method to register new user 
    public String registerUser(String username, String password, String cell) {
        if (checkUserName(username) && checkPasswordComplexity(password)) {
            this.registeredUsername = username;
            this.registeredPassword = password;
            this.registredCell = cell;
            return "Registration successful";
        }else {
            return "Registration failed. Please ensure the username and password meet the requirement.";
        }
    }
    //Method to log in user after comparing their input with registered details
    public String loginUser(String username, String password) {
        //Checks if input matches the username and the password
        if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
            return "Login successful.";
        } else {
            return "Login failed. Incorrect username or password.";
        }
    }
    //Method to return a welcome message after login
    public String returnLoginStatus(boolean isLoggedIn, String firstName, String lastName) {
        //If logged in , return customized welcome message
        if (isLoggedIn) {
            return "Welcome" + firstName + " " + lastName; 
        }
        //If not logged in, return an empty string
        return "";
    }
}
