/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quickchat;
import java.lang.reflect.Array;

import javax.swing.JOptionPane;
import java.util.ArrayList; 
/**
 *
 * @author RC_Student_Lab
 */
public class MessageSender {
    public static void main(String[] args){
        
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat");
        
        String name = JOptionPane.showInputDialog("Enter your name:");
        
        int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages?"));
        
        String choice = JOptionPane.showInputDialog("Choose an option:\n1. Send Message\n2. Show Recent\n3 Quit");
        int option = Integer.parseInt(choice);
        
        while (!choice.equals(3)) {
        if (choice ==null) {
            break;
        }
        if (choice.equals("1")) {
            JOptionPane.showMessageDialog(null, "Sending Message");
        }else if (choice.equals("2")) {
            JOptionPane.showMessageDialog(null, "Coming Soon");
        }else if (choice.equals("3")) {
            JOptionPane.showMessageDialog(null, "Goodbye!");
        }else {
            JOptionPane.showMessageDialog(null, "Invalid Choice, please try again");
        }
        }
    }
    public static void sendMessages(ArrayList<Message> messages) {
        try {
            int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages to send?"));
            for (int i = 0; i < count; i++) {
                String recipient = JOptionPane.showInputDialog("Enter recipient's number:");
                String text = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                //The message object
                Message msg = new Message();
                if (msg.isValid()) {
                    messages.add(msg);
                    JOptionPane.showMessageDialog(null, "Message ready to send:\n" + msg.printMessage());
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid message details.");
                }
            }
        
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number input.");
        }
    }
    public static void showRecentMessages(ArrayList<Message> messages) {
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No recent messages.");
            return;
        }
        StringBuilder allMessages = new StringBuilder("Recent Messages:\n\n");
        for (Message msg : messages) {
            allMessages.append(msg.printMessage()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, allMessages.toString());
    }
  }
