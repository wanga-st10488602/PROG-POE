/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quickchat;

import java.util.Scanner;
/**
 *
 * @author RC_Student_Lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();
        
        System.out.println("Welcome user to the registration and login system");
        // Asks user for firstname and lastname 
        System.out.println("Enter your first name:");
        String firstName = scanner.nextLine();
        System.out.println("Enter your last name:");
        String lastName = scanner.nextLine();
               
               
            
        //Registration
        //Asks user to create a username with given format
        System.out.println("Enter a username (must contain an underscore _ , and be 5 characters max):");
        String username = scanner.nextLine();
        //Asks user to create a password with given format
        System.out.println("Enter a password (min 8 characters, must contain a capital letter, a number, a special character):");
        String password = scanner.nextLine();
        //Asks user to provide their cell phone number with given format
        System.out.println("Enter your cell phone number (must start with + and be 7-15 digits long):");
        String cell = scanner.nextLine();
        
        boolean validUsername = loginSystem.checkUserName(username);
        boolean validPassword = loginSystem.checkPasswordComplexity(password);
        
        //validate username
        if (!validUsername) {
            System.out.println("Username is not correctly formatted. It must contain an underscore and be no more than 5 characters long.");
        }else {
            System.out.println("Valid username");
        }
        
        //validate password
        if (!validPassword) {
            System.out.println("Password is not correctly formatted. It must contain an underscore and be no more than 5 characters long.");
        }else {
            System.out.println("Valid password");
        }
        
        //login will be allowed if both are valid
        if (validUsername && validPassword) {
            System.out.println("Login successful. Welcome," + username);
        }else {
            System.out.println("Login unsuccessful. Please try again.");
        }
        
        
        String registrationStatus = loginSystem.registerUser(username, password, cell);
        System.out.println(registrationStatus);
        
        //Login
        if (registrationStatus.equals("Registration successful")) {
            //Asks user for registered username
            System.out.println("Enter your username to login:");
            String loginUsername = scanner.nextLine();
            //Asks user for registered password
            System.out.println("Enter your password to login:");
            String loginPassword = scanner.nextLine();
        }
        scanner.close();
    }
    
}
