/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quickchat;
import java.util.Random;

public class Message {
    private String messageId;
    private String recipient;
    private String text;
    private String hash;

    public Message() {
        this.recipient = recipient;
        this.text = text;
        this.messageId = generateMessageId();
        this.hash = createMessageHash();
    }
    private String generateMessageId() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }
    public boolean checkMessageId(String messageId) {
        return messageId.length() ==10;
    }
    public boolean checkRecipientCell() {
        return recipient.startsWith("+") && recipient.length() >= 10 && recipient.length() <= 13;
    }
    public boolean checkMessageLength() {
        return text.length() <= 250;
    }
    public String createMessageHash() {
        return messageId.substring(0, 4) + ":" + text.hashCode();
    }
    public boolean isValid() {
        if (!checkMessageId(messageId)) {
            javax.swing.JOptionPane.showMessageDialog(null, "Invalid Message ID");
            return false;
        }
        if (!checkRecipientCell()) {
            javax.swing.JOptionPane.showMessageDialog(null, "Invalid Recipient Cell Number");
            return false;
        }
        if (!checkMessageLength()) {
            int overBy = text.length() - 250;
            javax.swing.JOptionPane.showMessageDialog(null, "Message exceeds 250 characters");
            return false;
        }
        return true;
    }
    public String printMessage() {
        return "Message ID: " + messageId + "\nRecipient: " + recipient + "\nMessage: " + text + "\nHash: " + hash;
    }


}
