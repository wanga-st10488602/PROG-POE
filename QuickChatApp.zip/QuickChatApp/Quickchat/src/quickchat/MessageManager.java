/*>
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quickchat;
import java.util.*;



public class MessageManager {
    public ArrayList<String> sentMessages = new ArrayList<>();
    public ArrayList<String> disregardedMessages = new ArrayList<>();
    public ArrayList<String> storedMessages = new ArrayList<>(); 
    public ArrayList<String> messageHashes = new ArrayList<>();
    public ArrayList<String> messageIDs = new ArrayList<>();
    public ArrayList<String> recipients = new ArrayList<>();
    
    public void displaySenderRecipientForAllSent() {
        System.out.println("===SENT MESSAGES===");
        for (int i = 0; i < sentMessages.size(); i++) {
            System.out.println("To: " + recipients.get(i) + " - " + sentMessages.get(i));
        }
    }
    public String findAndDisplayLongestMessage() {
        String longest = "";
        for (String msg: sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }
    public String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                String message = getMessageAtIndex(i);
                String recipient = recipients.get(i);
                
                return "Message: " + message + "\nRecipient: " + recipient;
            }
        }
        return "Message ID not found.";
    }

    private String getMessageAtIndex(int i) {
        if (i < sentMessages.size())
            return sentMessages.get(i);
        if (i < sentMessages.size() + storedMessages.size())
            return storedMessages.get(i - sentMessages.size());
        return disregardedMessages.get(i - sentMessages.size() - storedMessages.size()); 
    }
    public ArrayList<String> searchMessageByRecipient(String number) {
        ArrayList<String> results = new ArrayList<>();
        
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(number)) {
                results.add(getMessageAtIndex(i));
            }
        }
        return results;
    }
    public boolean deleteMessageByHash(String hash) { 
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(0).equals(hash)) {
                
                messageHashes.remove(0);
                String removedID = messageIDs.remove(0);
                
                removeMessageObject(0);
                
                System.out.println("Message deleted successfully.");
                return true;
            }
    }
        System.out.println("Hash not found.");
        return false;
    }

    private void removeMessageObject(int i) {
        if (i < sentMessages.size()) {
            sentMessages.remove(i);
            return;
        }
        i -= sentMessages.size();
        
        if (i < disregardedMessages.size()) {
            disregardedMessages.remove(i);
        }
    }
    public void displayFullReport() {
        System.out.println("===FULL MESSAGE REPORT===");
        for (int i = 0; i < messageIDs.size(); i++) {
            System.out.println("----------------------------------------");
            System.out.println("Message ID: " + messageIDs.get(i));
            System.out.println("Message Hash: " + messageHashes.get(i));
            System.out.println("Recipient: " + recipients.get(i));
            System.out.println("Message: " + getMessageAtIndex(i));
        }
    }
    
    
}
